package Interfaz;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JList;

public class CustomListCellRenderer extends DefaultListCellRenderer {

    @Override
    public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
        Component component = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

        // Personalizar la apariencia del componente aqu�
        // Ejemplo:
        if (index < 3) {
            component.setForeground(Color.GREEN);
        } else if (index == 3) {
            component.setForeground(Color.BLUE);
        } else {
            component.setForeground(Color.BLACK);

        }
        
        component.setFont(component.getFont().deriveFont(10.0f).deriveFont(Font.BOLD));

        return component;
    }

}
