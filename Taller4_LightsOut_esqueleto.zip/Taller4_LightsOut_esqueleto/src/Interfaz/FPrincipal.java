package Interfaz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.UIManager;

import uniandes.dpoo.taller4.modelo.Tablero;

public class FPrincipal extends JFrame implements ActionListener {
    private JPanel panelCentral = new JPanel(new GridLayout(5,5));
    private JComboBox<Integer> comboBox;
    private JButton[][] matrizBotones;
    private int dimension;
    private int jugadas;
    private String jugador = "Anonimo";
    private boolean [][] luces;
    private Tablero tablero;
	private JRadioButton facil = new JRadioButton();
	private JRadioButton medio;
	private JRadioButton dificil;
    private JLabel numJugadasLabel;
    private JLabel nombreJugadorLabel;


    public FPrincipal(int dimension) {
    	
        super("Lights Out");
        tablero = new Tablero(dimension);
        JOptionPane.showMessageDialog(null, "Por favor, primero crea el tablero", "Aviso", JOptionPane.WARNING_MESSAGE);
        JLabel etiqueta = new JLabel("Da click en" + " nuevo" + " ---------->");
        Font font = new Font("Montserrat", Font.BOLD, 15);
        etiqueta.setFont(font); // cambia la tipograf�a y el tama�o de la letra
        etiqueta.setForeground(Color.RED);
        panelCentral.add(etiqueta);
        facil.setSelected(true);
        
        Integer[] sizes = {4, 5, 6, 7, 8};
        comboBox = new JComboBox<>(sizes);
        comboBox.setFont(font);
        comboBox.setPreferredSize(new Dimension(100, 50));

        
        // Crear los JRadioButton y agregarlos al panel de radio buttons
        JPanel panelRadioButtons = new JPanel(new GridLayout(3, 1));
        panelRadioButtons.setBorder(BorderFactory.createTitledBorder("Dificultad"));

        facil = new JRadioButton("Facil");
        facil.setFont(font);
        medio = new JRadioButton("Medio");
        medio.setFont(font);
        dificil = new JRadioButton("Dificil");
        dificil.setFont(font);

        panelRadioButtons.add(facil);
        panelRadioButtons.add(medio);
        panelRadioButtons.add(dificil);
        
        // Agregar radio buttons al panel principal
        JPanel panelRadio = new JPanel();
        panelRadio.add(comboBox);
        panelRadio.add(panelRadioButtons);
        add(panelRadio, BorderLayout.NORTH);

        // Agregar panel de botones al panel principal
        add(panelCentral, BorderLayout.CENTER);
        
        JPanel panel = new JPanel(new BorderLayout());

        // Crear JLabels para "Jugadas:" y "jugador:"
        JLabel jugadasLabel = new JLabel("Jugadas: ");
        JLabel jugadorLabel = new JLabel("Jugador: ");

        // Crear JLabels para mostrar los valores de jugadas y jugador
        numJugadasLabel = new JLabel(Integer.toString(jugadas));
        nombreJugadorLabel = new JLabel("Anonimo");

        // A�adir los JLabels al panel en las posiciones adecuadas
        panel.add(jugadasLabel, BorderLayout.WEST);
        panel.add(jugadorLabel, BorderLayout.EAST);
        panel.add(numJugadasLabel, BorderLayout.CENTER);
        panel.add(nombreJugadorLabel, BorderLayout.EAST);
        add(panel, BorderLayout.SOUTH);
        
        // Crear contenedor para el norte
        JPanel panelNorte = new JPanel(new BorderLayout());

        // Crear panel para el JComboBox y agregarlo al contenedor del norte
        JPanel panelComboBox = new JPanel();
        panelComboBox.add(comboBox);
        panelNorte.add(panelComboBox, BorderLayout.WEST);



        // Agrupar los JRadioButton para que solo uno pueda ser seleccionado a la vez
        ButtonGroup group = new ButtonGroup();
        group.add(facil);
        group.add(medio);
        group.add(dificil);
        // Agregar panel de radio buttons al contenedor del norte
        panelNorte.add(panelRadioButtons, BorderLayout.CENTER);

        // Agregar contenedor del norte al panel principal
        add(panelNorte, BorderLayout.NORTH);
     // Crear panel de botones izquierdo
        JPanel panelBotonesIzquierdo = new JPanel(new GridLayout(5, 1));

        // Crear botones
        JButton botonNuevo = new JButton("Nuevo");
        botonNuevo.setFont(font);
        botonNuevo.addActionListener(FPrincipal.this);
        JButton botonReiniciar = new JButton("Reiniciar");
        botonReiniciar.setFont(font);
        botonReiniciar.addActionListener(FPrincipal.this);
        JButton botonTop10 = new JButton("Top 10");
        botonTop10.setFont(font);
        botonTop10.addActionListener(FPrincipal.this);
        JButton botonCambiarJugador = new JButton("Cambiar Jugador");
        botonCambiarJugador.setFont(font);
        botonCambiarJugador.addActionListener(FPrincipal.this);

        // Agregar botones al panel de botones izquierdo
        panelBotonesIzquierdo.add(botonNuevo);
        panelBotonesIzquierdo.add(botonReiniciar);
        panelBotonesIzquierdo.add(botonTop10);
        panelBotonesIzquierdo.add(botonCambiarJugador);

        // Agregar panel de botones izquierdo al panel principal
        add(panelBotonesIzquierdo, BorderLayout.EAST);



        // Agregar componentes al panel principal
        add(panelCentral, BorderLayout.CENTER);


    }
    public void crearTablero(int dimension, String accion) {
    	panelCentral.removeAll();
    	panelCentral.setLayout(new GridLayout(dimension, dimension));
    	matrizBotones = new JButton[dimension][dimension];
    	
    	if (accion == "Nuevo") {
    		luces = tablero.darTablero();
        }else if (accion == "Reiniciar") {
        	if (tablero.darJugadas() != 0){
            tablero.reiniciar();
    		luces = tablero.darTablero();
        	}
        }
    	
        tablero.salvar_tablero();

    	for (int i = 0; i < dimension; i++) {
    		int fila = i;
    		for (int j = 0; j < dimension; j++) {
    			int columna = j;
    			matrizBotones[i][j] = new JButton("");
    			if (luces[i][j]) {
            	    matrizBotones[i][j].setOpaque(true);
            	    matrizBotones[i][j].setBorderPainted(false); 
            	    matrizBotones[i][j].setBackground(Color.YELLOW);
	    			matrizBotones[i][j].setForeground(Color.YELLOW);
            	    matrizBotones[i][j].setSelected(true);
	            	matrizBotones[i][j].repaint();


            	}else {
            	    matrizBotones[i][j].setOpaque(true);
            	    matrizBotones[i][j].setBorderPainted(false); 
            	    matrizBotones[i][j].setBackground(Color.WHITE);
	    			matrizBotones[i][j].setForeground(Color.WHITE);
            	    matrizBotones[i][j].setSelected(false);
	            	matrizBotones[i][j].repaint();

            	}
    			matrizBotones[i][j].setBorderPainted(true); 
    	    	matrizBotones[i][j].addActionListener(this);
    	    	matrizBotones[i][j].repaint();
    	    	matrizBotones[i][j].addMouseListener(new java.awt.event.MouseAdapter() {
    	    		public void mousePressed(java.awt.event.MouseEvent evt) {
    	    			tablero.jugar(fila, columna);
    	    			jugadas = tablero.darJugadas();
    	    			numJugadasLabel.setText(Integer.toString(jugadas));
    	    			
    	    	        for (int i = 0; i < matrizBotones.length; i++) {
    	    	            for (int j = 0; j < matrizBotones.length; j++) {
    	    	            	if (luces[i][j]) {
    	    	            	    matrizBotones[i][j].setOpaque(true);
    	    	            	    matrizBotones[i][j].setBorderPainted(false); 
    	    	            	    matrizBotones[i][j].setBackground(Color.YELLOW);
    	    		    			matrizBotones[i][j].setForeground(Color.YELLOW);
    	    	            	    matrizBotones[i][j].setSelected(true);


    	    	            	}else {
    	    	            	    matrizBotones[i][j].setOpaque(true);
    	    	            	    matrizBotones[i][j].setBorderPainted(false); 
    	    	            	    matrizBotones[i][j].setBackground(Color.WHITE);
    	    		    			matrizBotones[i][j].setForeground(Color.WHITE);
    	    	            	    matrizBotones[i][j].setSelected(false);


    	    	            	}

    	    	            	matrizBotones[i][j].repaint();
    	    	            }
    	    	        }
    	    	        if (tablero.tableroIluminado()) {
    	    		    	int puntaje = tablero.calcularPuntaje();
    	    		        JPanel panel = new JPanel();
    	    		        panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
    	    		        
    	    		        JLabel textLabel = new JLabel("�Gracias por iluminarme! Crea un nuevo tablero :)\n" + jugador + " tu puntaje es: " + Integer.toString(puntaje) );
    	    		        JLabel imageLabel = new JLabel(new ImageIcon("data/winner.png"));  	    		        
    	    		        panel.add(imageLabel);
    	    		        panel.add(Box.createRigidArea(new Dimension(10,0)));
    	    		        panel.add(textLabel);
    	    		        panel.repaint();
    	    		        
    	    		        UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 16));
    	    		        JOptionPane.showMessageDialog(null, panel, "Felicidades", JOptionPane.PLAIN_MESSAGE);
    	    		    	panelCentral.removeAll();
        	    			numJugadasLabel.setText(Integer.toString(0));
    	    		    	panelCentral.repaint();
    	    		    	add(panelCentral);
    	    			}
    	    	        
    	    	    
                    
    	    		}
    	    		public void mouseEntered(java.awt.event.MouseEvent evt) {
    	    			if (!matrizBotones[fila][columna].isSelected()) {
    	    			matrizBotones[fila][columna].setBackground(Color.YELLOW);
    	    			matrizBotones[fila][columna].setForeground(Color.YELLOW);
    	    			
    	    			}
    	    		}
    	    		public void mouseExited(java.awt.event.MouseEvent evt) {
    	    			if (!matrizBotones[fila][columna].isSelected()) {
    	    			matrizBotones[fila][columna].setBackground(Color.WHITE);
    	    			matrizBotones[fila][columna].setForeground(Color.WHITE);
    	    			}
    	    		}
              
    	    	});
    	    	panelCentral.add(matrizBotones[i][j]);
            
    		}
    		panelCentral.revalidate();
    		panelCentral.repaint();
    }

    }

    public void actionPerformed(ActionEvent e) {
    	JButton boton = (JButton)e.getSource();
    	dimension = (int) comboBox.getSelectedItem();
    	
    	
    	if (boton.getText() == "Nuevo"){
    			if (facil.isSelected()){  
    		    	tablero = new Tablero(dimension);
    				tablero.desordenar(10);
    				this.crearTablero(dimension,"Nuevo");

    			}else if (medio.isSelected()){
    				tablero = new Tablero(dimension);
    				tablero.desordenar(25);
    				this.crearTablero(dimension,"Nuevo");

    			}else if (dificil.isSelected()){
    				tablero = new Tablero(dimension);
    				tablero.desordenar(50);
    				this.crearTablero(dimension,"Nuevo");
    			}else {
    		        JOptionPane.showMessageDialog(null, "Por favor, selecciona una dificultad antes de crearlo", "Aviso", JOptionPane.WARNING_MESSAGE);
    			}
    	}else if (boton.getText() == "Reiniciar"){
    		crearTablero(dimension, "Reiniciar");
    	}else if (boton.getText() == "Cambiar Jugador") {
    		System.out.println("holaaa");
            jugador = JOptionPane.showInputDialog(null, "Ingrese el nuevo nombre del jugador");
            if (jugador == null || jugador.equals("")) {
                jugador = "Anonimo";
            }
            nombreJugadorLabel.setText(jugador);
        }else if (boton.getText() == "Top 10") {
        	JPanel panel = new JPanel();
	        panel.setLayout(new BoxLayout(panel, BoxLayout.X_AXIS));
	        JLabel textLabel = new JLabel(jugador);
        	JList<String> myList = new JList<>(new String[] {"Elemento 1", "Elemento 2", "Elemento 3", "Elemento 4", "Elemento 5", "Elemento 5", "Elemento 5","Elemento 5", "Elemento 5"});
        	myList.setCellRenderer(new CustomListCellRenderer());
            JScrollPane scrollPane = new JScrollPane(myList);
            panel.add(textLabel);
	        panel.add(Box.createRigidArea(new Dimension(10,0)));
        	panel.add(scrollPane);
        	panel.repaint();
	        JOptionPane.showMessageDialog(null, panel, "Top 10", JOptionPane.PLAIN_MESSAGE);
        }
        }
    	
    
    	
    	
    

    public static void main(String[] args) {
        FPrincipal fPrincipal = new FPrincipal(4);
		fPrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fPrincipal.setSize(500, 500);
        fPrincipal.setLocationRelativeTo(null);
        fPrincipal.setVisible(true);
    }
}